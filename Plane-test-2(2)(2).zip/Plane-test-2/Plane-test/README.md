This is my simple Plane quiz web app built using Node.js, express and EJS.

Index.js is the main server file, package.json contains the project dependencies, views/ contains the EJS templates for the page, public/ contains static files, like CSS and images.

You can unzip the folder and open it in VS Code or any code editor to see the code.

To run it locally, install Node.js, run npm install, then node index.js, and open http://localhost:3000 in a browser.