const express = require('express');
const app = express();
app.set('view engine', 'ejs');
app.use(express.static('public'));
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/', (req, res) => {
  res.render('index');
});



app.post('/planes', (req, res) => {
  res.render('planes');
})
app.post('/aboutplanes', (req, res) => {
  res.render('aboutplanes');
})

app.post('/Test1', (req, res) => {
  res.render('Test1');
})

app.post('/Test2', (req, res) => {
  res.render('Test2');
})

app.post('/Test3', (req, res) => {
  console.log("submitted data");
  if(req.body.answer == "a380" || req.body.answer == "A380" || req.body.answer == "Airbus A380" || req.body.answer == "Airbus a380" || req.body.answer == "airbus a380" || req.body.answer == "Airbus a380" || req.body.answer == "airbus A380" || req.body.answer == "AIRBUS A380" || req.body.answer == "AIRBUS a380"){
    console.log("Correct");
    var result = "Correct";
  }
  else{
    console.log("Incorrect");
    var result = "Incorrect";
  }
  res.render('Test3', {result: result});
})

app.post('/Test4', (req, res) => {
  res.render('Test4');
})

app.post('/Test5', (req, res) => {
  console.log("submitted data");
  if(req.body.answer == "747" || req.body.answer == "Boeing 747" || req.body.answer == "boeing 747" || req.body.answer == "BOEING 747"){
    console.log("Correct");
    var result = "Correct";
}
  else{
    console.log("Incorrect");
    var result = "Incorrect";
  }
  res.render('Test5', {result: result});
  });

app.post('/Test6', (req, res) => {
  res.render('Test6');
})
app.post('/Test7', (req, res) => {
  console.log("submitted data");
  if(req.body.answer == "A340" || req.body.answer == "Airbus A340" || req.body.answer == "airbus a340" || req.body.answer == "airbus A340" || req.body.answer == "a340" || req.body.answer == "AIRBUS A340" || req.body.answer == "AIRBUS a340"){
    console.log("Correct");
    var result = "Correct";
  }
  else{
    console.log("Incorrect");
    var result = "Incorrect";
  }
  res.render('Test7', {result: result});
});
app.post('/Test8', (req, res) => {
  res.render('Test8');
})
app.post('/Test9', (req, res) => {
  console.log("submitted data");
  if(req.body.answer == "787" || req.body.answer == "Boeing 787" || req.body.answer == "boeing 787" || req.body.answer == "BOEING 787"  ||  req.body.answer == "Boeing 787-MAX"  ||  req.body.answer == "BOEING 787 MAX"  ||  req.body.answer == "boeing 787 MAX"  ||  req.body.answer == "Boeing 787 max"  ||  req.body.answer == "boeing 787 max"  ||  req.body.answer == "787-max"  ||  req.body.answer ==  "787 MAX" ||  req.body.answer ==  "boeing 787 MAX"){
    console.log("Correct");
    var result = "Correct";
  }
  else{
    console.log("Incorrect");
    var result = "Incorrect";
  }
  res.render('Test9', {result: result});
    });

  app.post('/Test10', (req, res) => {
    res.render('Test10');
  })
  app.post('/Test11', (req, res) => {
    console.log("submitted data");
    console.log(req.body.answer);
    if(req.body.answer == "737" || req.body.answer == "Boeing 737" || req.body.answer == "boeing 737" || req.body.answer == "BOEING 737"){
      console.log("Correct");
      var result = "Correct";
    }
    else{
      console.log("Incorrect");
      var result = "Incorrect";
    }
    res.render('Test11', {result: result});
  });
    app.post('/Test12', (req, res) => {
      res.render('Test12');
    })

    app.post('/Test13', (req, res) => {
      console.log("submitted data");
      if(req.body.answer == "777" || req.body.answer == "Boeing 777" || req.body.answer == "boeing 777" || req.body.answer == "BOEING 777")
      {
        console.log("Correct");
        var result = "Correct";
      }
      else{
        console.log("Incorrect");
        var result = "Incorrect";
      }
      res.render('Test13', {result: result});
    });


app.post('/ENDOFTEST', (req, res) =>{
  res.render('ENDOFTEST');
})




app.listen(3000, () => {
  console.log('Server listening on port 3000');
});